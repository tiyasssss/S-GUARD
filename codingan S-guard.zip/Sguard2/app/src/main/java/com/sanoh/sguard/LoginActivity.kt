package com.sanoh.sguard

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login) // Pastikan nama layout login-mu benar

        // Ambil ID tombol dari layout (Misal ID-nya: btnLogin)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            // Perintah untuk pindah ke MainActivity (Dashboard)
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // Menutup halaman login agar tidak bisa 'Back' ke sini lagi
            finish()
        }
    }
}