package com.sanoh.sguard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button // Pastikan ini sesuai dengan jenis view di XML
import androidx.fragment.app.Fragment

class ReportFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // 1. Inflate layout fragment_report
        val view = inflater.inflate(R.layout.fragment_report, container, false)

        // 2. Inisialisasi tombol Tambah Laporan
        // Pastikan di fragment_report.xml ID tombolnya adalah @+id/btnTambahLaporan
        val btnTambah = view.findViewById<Button>(R.id.btnTambahLaporan)

        btnTambah?.setOnClickListener {
            // 3. Pindah ke AddReportActivity
            val intent = Intent(requireContext(), AddReportActivity::class.java)
            startActivity(intent)
        }

        return view
    }
}