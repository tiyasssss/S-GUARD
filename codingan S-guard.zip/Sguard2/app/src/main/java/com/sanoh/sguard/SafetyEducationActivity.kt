package com.sanoh.sguard

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class SafetyEducationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_safety_education)

        // 1. Setup Judul Dinamis
        val kategori = intent.getStringExtra("CATEGORY")
        val tvTitle = findViewById<TextView>(R.id.tvTitleApd)

        when (kategori) {
            "CHEMICAL" -> tvTitle?.text = "Chemical Safety"
            "FIRE" -> tvTitle?.text = "Fire Safety"
            "ERGONOMI" -> tvTitle?.text = "Ergonomi Kerja"
            else -> tvTitle?.text = "Basic PPE"
        }

        // 2. Tombol Back
        findViewById<ImageView>(R.id.btnBackEduDetail)?.setOnClickListener {
            finish()
        }

        // 3. Logika Klik Menu Artikel
        findViewById<LinearLayout>(R.id.row_pengertian)?.setOnClickListener {
            val intent = Intent(this, ApdDasarDetailActivity::class.java)
            startActivity(intent)
        }

        // Menu lainnya menggunakan Toast
        setupMenuToast(R.id.row_jenis, "Detail Jenis")
        setupMenuToast(R.id.row_cara_penggunaan, "Cara Penggunaan")
        setupMenuToast(R.id.row_standar_sanoh, "Standar Sanoh")
        setupMenuToast(R.id.row_gambar_apd, "Gambar APD")

        // 4. KONFIGURASI BOTTOM NAVIGATION
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        // Warna indikator aktif (kapsul ungu)
        bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(Color.parseColor("#EADDFF"))

        // Tetap nyalakan ikon home karena ini masih bagian dari konten edukasi
        bottomNav.selectedItemId = R.id.navigation_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Kembali ke Dashboard (MainActivity)
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                    finish() // Tutup halaman ini
                    true
                }
                R.id.navigation_report -> {
                    // PERBAIKAN: Kirim instruksi ke MainActivity untuk buka ReportFragment
                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("OPEN_FRAGMENT", "REPORT")
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                    finish() // Tutup halaman edukasi
                    true
                }
                R.id.navigation_profile -> {
                    // Membuka ProfileActivity
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    // Return false agar indikator tetap di ikon Home (karena Profile adalah activity lain)
                    false
                }
                else -> false
            }
        }
    }

    private fun setupMenuToast(id: Int, pesan: String) {
        findViewById<LinearLayout>(id)?.setOnClickListener {
            Toast.makeText(this, "Membuka $pesan", Toast.LENGTH_SHORT).show()
        }
    }
}