package com.sanoh.sguard

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNav = findViewById(R.id.bottom_navigation)
        bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(Color.parseColor("#EADDFF"))

        // --- LOGIKA PENERIMA INSTRUKSI DARI ACTIVITY LAIN ---
        val fragmentToOpen = intent.getStringExtra("OPEN_FRAGMENT")

        if (fragmentToOpen == "REPORT") {
            // Jika ada pesan "REPORT", langsung tampilkan ReportFragment
            replaceFragment(ReportFragment())
            bottomNav.selectedItemId = R.id.navigation_report
        } else {
            // Jika normal (buka aplikasi biasa), tampilkan Home
            if (savedInstanceState == null) {
                replaceFragment(HomeFragment())
                bottomNav.selectedItemId = R.id.navigation_home
            }
        }

        // --- LOGIKA KLIK BOTTOM NAVIGATION ---
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    if (bottomNav.selectedItemId != R.id.navigation_home) {
                        replaceFragment(HomeFragment())
                    }
                    true
                }
                R.id.navigation_report -> {
                    if (bottomNav.selectedItemId != R.id.navigation_report) {
                        replaceFragment(ReportFragment())
                    }
                    true
                }
                R.id.navigation_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    false
                }
                else -> false
            }
        }
    }

    // PENTING: Tambahkan fungsi ini agar jika MainActivity sudah terbuka,
    // instruksi "REPORT" dari Safety tetap terbaca.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val fragmentToOpen = intent.getStringExtra("OPEN_FRAGMENT")
        if (fragmentToOpen == "REPORT") {
            replaceFragment(ReportFragment())
            bottomNav.selectedItemId = R.id.navigation_report
        }
    }

    fun replaceFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
        fragmentTransaction.replace(R.id.fragment_container, fragment)
        fragmentTransaction.commit()
    }

    override fun onBackPressed() {
        if (bottomNav.selectedItemId != R.id.navigation_home) {
            bottomNav.selectedItemId = R.id.navigation_home
            replaceFragment(HomeFragment())
        } else {
            super.onBackPressed()
        }
    }
}