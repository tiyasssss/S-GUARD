package com.sanoh.sguard

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class ApdDasarDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apd_dasar_detail)

        // 1. Tombol Back (Kembali ke halaman sebelumnya/SafetyEducationActivity)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack?.setOnClickListener {
            finish()
        }

        // 2. Setup Navigasi Bawah
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        // Warna ungu kapsul indikator
        bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(Color.parseColor("#EADDFF"))

        // Tetap tandai Home karena ini adalah detail dari menu edukasi
        bottomNav.selectedItemId = R.id.navigation_home

        // 3. Logika Klik Navigasi Bawah
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Kembali ke Dashboard utama (MainActivity)
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.navigation_report -> {
                    // MUNCULKAN REPORT: Kirim instruksi ke MainActivity
                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("OPEN_FRAGMENT", "REPORT")
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.navigation_profile -> {
                    // Pindah ke ProfileActivity
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    // Return false agar ikon Home tetap menyala di background
                    false
                }
                else -> false
            }
        }
    }
}