package com.sanoh.sguard

import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddReportActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_report)

        // Inisialisasi View
        val btnBack = findViewById<ImageView>(R.id.btnBackAddReport)
        val btnTakePhoto = findViewById<LinearLayout>(R.id.btnTakePhoto)
        val btnKirim = findViewById<Button>(R.id.btnKirimLaporan)
        val etDeskripsi = findViewById<EditText>(R.id.etDeskripsi)
        val spinnerKategori = findViewById<Spinner>(R.id.spinnerKategori)

        // 1. Fungsi Kembali
        btnBack?.setOnClickListener {
            finish()
        }

        // 2. Fungsi Ambil Foto (Buka Kamera)
        btnTakePhoto?.setOnClickListener {
            val intentKamera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            // Perbaikan: Di Android modern, resolveActivity seringkali mengembalikan null
            // kecuali jika dideklarasikan di Manifest. Lebih aman langsung try-catch.
            try {
                startActivity(intentKamera)
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membuka kamera", Toast.LENGTH_SHORT).show()
            }
        }

        // 3. Setup Spinner
        // Pastikan R.string.prompt_kategori ada di strings.xml
        val items = arrayOf(
            "Pilih Kategori", // Kamu bisa pakai getString(R.string.prompt_kategori)
            "Fisik", "Kimia", "Biologi", "Ergonomi"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerKategori.adapter = adapter

        // 4. Fungsi Tombol Kirim
        btnKirim?.setOnClickListener {
            val dataDeskripsi = etDeskripsi.text.toString()

            if (dataDeskripsi.isEmpty() || spinnerKategori.selectedItemPosition == 0) {
                // Beri peringatan jika deskripsi kosong atau kategori belum dipilih
                Toast.makeText(this, "Harap lengkapi kategori dan deskripsi", Toast.LENGTH_SHORT).show()
            } else {
                // Munculkan pesan sukses
                Toast.makeText(this, "Laporan Berhasil Terkirim!", Toast.LENGTH_LONG).show()
                finish() // Kembali ke ReportFragment
            }
        }
    }
}