package com.sanoh.sguard

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class SafetyMainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_safety_main)

        // 1. Tombol Back (Menghancurkan activity ini dan balik ke MainActivity yang sudah ada)
        val btnBack = findViewById<ImageView>(R.id.btnBackEduMain)
        btnBack.setOnClickListener {
            finish()
        }

        // 2. Klik Menu APD Dasar
        val btnBasicPpe = findViewById<LinearLayout>(R.id.menu_apd_dasar)
        btnBasicPpe.setOnClickListener {
            val intent = Intent(this, SafetyEducationActivity::class.java)
            intent.putExtra("CATEGORY", "BASIC_PPE")
            startActivity(intent)
        }

        // 3. Setup Bottom Navigation
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(Color.parseColor("#EADDFF"))

        // Tetap tandai Home karena Safety adalah sub-menu dari Home
        bottomNav.selectedItemId = R.id.navigation_home

        // 4. Logika Navigasi
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Cukup finish karena MainActivity sudah ada di tumpukan bawah (backstack)
                    finish()
                    true
                }
                R.id.navigation_report -> {
                    // PANGGIL MainActivity sambil bawa pesan "REPORT"
                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("OPEN_FRAGMENT", "REPORT")

                    // CLEAR_TOP memastikan kita balik ke MainActivity yang lama, bukan buat baru
                    // SINGLE_TOP memastikan tidak ada animasi restart yang kasar
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP

                    startActivity(intent)
                    finish() // Tutup halaman safety
                    true
                }
                R.id.navigation_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    false // Biarkan indikator tetap di Home/Safety
                }
                else -> false
            }
        }
    }
}