package com.sanoh.sguard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // 1. Tombol Hazard -> Ke ReportFragment (Bukan langsung Activity)
        val btnHazard = view.findViewById<LinearLayout>(R.id.menu_hazard_report)
        btnHazard.setOnClickListener {
            // Perintahkan MainActivity untuk ganti fragment
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.replaceFragment(ReportFragment())

                // Update ikon navigasi bawah agar pindah ke ikon Report
                val bottomNav = mainActivity.findViewById<BottomNavigationView>(R.id.bottom_navigation)
                bottomNav.selectedItemId = R.id.navigation_report
            }
        }

        // 2. Tombol Checklist -> Tetap ke ChecklistActivity (Halaman Penuh)
        val btnCeklis = view.findViewById<LinearLayout>(R.id.menu_checklist)
        btnCeklis.setOnClickListener {
            val intent = Intent(requireContext(), ChecklistActivity::class.java)
            startActivity(intent)
        }

        // 3. Tombol Edukasi -> Ke SafetyMainActivity
        val btnEdu = view.findViewById<LinearLayout>(R.id.menu_safety_edu)
        btnEdu?.setOnClickListener {
            val intent = Intent(requireContext(), SafetyMainActivity::class.java)
            startActivity(intent)
        }

        return view
    }
}