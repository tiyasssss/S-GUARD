package com.sanoh.sguard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Inisialisasi View (Pastikan ID ivFlag dan tvCountryName ada di XML)
        val ivFlag = findViewById<ImageView>(R.id.ivFlag)
        val tvCountry = findViewById<TextView>(R.id.tvCountryName)

        // Deteksi Lokasi Emulator/HP
        val config = resources.configuration
        val locale = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            config.locales[0]
        } else {
            @Suppress("DEPRECATION")
            config.locale
        }

        val countryCode = locale?.country ?: "ID"

        // Logika Ganti Bendera & Teks Otomatis
        if (countryCode.equals("SG", ignoreCase = true)) {
            tvCountry.text = "\"Singapore\""
            ivFlag.setImageResource(R.drawable.flag_singapore)
        } else {
            tvCountry.text = "\"Indonesia\""
            ivFlag.setImageResource(R.drawable.flag_indonesia)
        }

        // Pindah ke halaman berikutnya
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }, 3000)
    }
}