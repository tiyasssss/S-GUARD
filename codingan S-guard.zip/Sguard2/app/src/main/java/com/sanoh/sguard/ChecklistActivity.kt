package com.sanoh.sguard

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ChecklistActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checklist)

        // HUBUNGKAN TOMBOL BACK
        val btnBack = findViewById<ImageView>(R.id.btnBackChecklist)

        btnBack.setOnClickListener {
            // Menutup halaman ceklis dan kembali ke HomeFragment
            finish()
        }
    }
}